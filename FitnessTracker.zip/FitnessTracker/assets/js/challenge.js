/**
 * JavaScript for challenge functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Challenge filter
    const filterButtons = document.querySelectorAll('.challenge-filter-btn');
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const difficulty = this.getAttribute('data-difficulty');
                const challenges = document.querySelectorAll('.challenge-card');
                
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                // Filter challenges
                challenges.forEach(challenge => {
                    if (difficulty === 'all' || challenge.getAttribute('data-difficulty') === difficulty) {
                        challenge.style.display = 'block';
                    } else {
                        challenge.style.display = 'none';
                    }
                });
            });
        });
    }

    // Challenge duration filter
    const durationFilter = document.getElementById('durationFilter');
    if (durationFilter) {
        durationFilter.addEventListener('change', function() {
            const duration = parseInt(this.value);
            const challenges = document.querySelectorAll('.challenge-card');
            
            challenges.forEach(challenge => {
                const challengeDuration = parseInt(challenge.getAttribute('data-duration'));
                
                if (duration === 0 || (challengeDuration <= duration)) {
                    challenge.style.display = 'block';
                } else {
                    challenge.style.display = 'none';
                }
            });
        });
    }

    // Challenge search
    const challengeSearch = document.getElementById('challengeSearch');
    if (challengeSearch) {
        challengeSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const challenges = document.querySelectorAll('.challenge-card');
            
            challenges.forEach(challenge => {
                const title = challenge.querySelector('.card-title').textContent.toLowerCase();
                const description = challenge.querySelector('.card-text').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || description.includes(searchTerm)) {
                    challenge.style.display = 'block';
                } else {
                    challenge.style.display = 'none';
                }
            });
        });
    }

    // Join challenge button
    const joinChallengeButtons = document.querySelectorAll('.join-challenge-btn');
    if (joinChallengeButtons.length > 0) {
        joinChallengeButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                const challengeId = this.getAttribute('data-challenge-id');
                const button = this;
                
                // Add loading state
                button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Joining...';
                button.disabled = true;
                
                // Create an XMLHttpRequest object
                const xhr = new XMLHttpRequest();
                
                // Define what happens on successful data submission
                xhr.addEventListener('load', function(e) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        
                        if (response.success) {
                            // Update button
                            button.className = 'btn btn-success';
                            button.innerHTML = '<i class="fas fa-check"></i> Joined';
                            button.disabled = true;
                            
                            // Show success message
                            const alertContainer = document.getElementById('alertContainer');
                            if (alertContainer) {
                                const alertElement = document.createElement('div');
                                alertElement.className = 'alert alert-success alert-dismissible fade show';
                                alertElement.innerHTML = `
                                    ${response.message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                `;
                                
                                alertContainer.appendChild(alertElement);
                                
                                // Auto-dismiss alert after 5 seconds
                                setTimeout(function() {
                                    const alerts = document.querySelectorAll('.alert');
                                    alerts.forEach(alert => {
                                        const bsAlert = new bootstrap.Alert(alert);
                                        bsAlert.close();
                                    });
                                }, 5000);
                            }
                        } else {
                            // Reset button
                            button.innerHTML = 'Join Challenge';
                            button.disabled = false;
                            
                            // Show error message
                            const alertContainer = document.getElementById('alertContainer');
                            if (alertContainer) {
                                const alertElement = document.createElement('div');
                                alertElement.className = 'alert alert-danger alert-dismissible fade show';
                                alertElement.innerHTML = `
                                    ${response.message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                `;
                                
                                alertContainer.appendChild(alertElement);
                            }
                        }
                    } catch (error) {
                        // Reset button
                        button.innerHTML = 'Join Challenge';
                        button.disabled = false;
                        
                        // Show error message
                        const alertContainer = document.getElementById('alertContainer');
                        if (alertContainer) {
                            const alertElement = document.createElement('div');
                            alertElement.className = 'alert alert-danger alert-dismissible fade show';
                            alertElement.innerHTML = `
                                An error occurred. Please try again.
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            `;
                            
                            alertContainer.appendChild(alertElement);
                        }
                    }
                });
                
                // Define what happens in case of error
                xhr.addEventListener('error', function(e) {
                    // Reset button
                    button.innerHTML = 'Join Challenge';
                    button.disabled = false;
                    
                    // Show error message
                    const alertContainer = document.getElementById('alertContainer');
                    if (alertContainer) {
                        const alertElement = document.createElement('div');
                        alertElement.className = 'alert alert-danger alert-dismissible fade show';
                        alertElement.innerHTML = `
                            An error occurred while joining the challenge. Please try again.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        `;
                        
                        alertContainer.appendChild(alertElement);
                    }
                });
                
                // Set up our request
                xhr.open('POST', 'join-challenge.php');
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                
                // Send the form data
                xhr.send(`challenge_id=${challengeId}`);
            });
        });
    }

    // Update challenge progress
    const updateProgressForm = document.getElementById('updateProgressForm');
    if (updateProgressForm) {
        updateProgressForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const challengeId = this.getAttribute('data-challenge-id');
            
            // Add loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Updating...';
            submitBtn.disabled = true;
            
            // Create an XMLHttpRequest object
            const xhr = new XMLHttpRequest();
            
            // Define what happens on successful data submission
            xhr.addEventListener('load', function(e) {
                try {
                    const response = JSON.parse(xhr.responseText);
                    
                    if (response.success) {
                        // Update progress bar
                        const progressBar = document.querySelector('.progress-bar');
                        if (progressBar) {
                            const newProgress = parseInt(formData.get('progress'));
                            progressBar.style.width = `${newProgress}%`;
                            progressBar.setAttribute('aria-valuenow', newProgress);
                            progressBar.textContent = `${newProgress}%`;
                            
                            // Update challenge status if needed
                            if (newProgress >= 100) {
                                const statusBadge = document.querySelector('.challenge-status');
                                if (statusBadge) {
                                    statusBadge.className = 'badge bg-success challenge-status';
                                    statusBadge.textContent = 'Completed';
                                }
                                
                                // Show completion message
                                const completionMessage = document.getElementById('completionMessage');
                                if (completionMessage) {
                                    completionMessage.classList.remove('d-none');
                                }
                            } else if (newProgress > 0) {
                                const statusBadge = document.querySelector('.challenge-status');
                                if (statusBadge) {
                                    statusBadge.className = 'badge bg-warning challenge-status';
                                    statusBadge.textContent = 'In Progress';
                                }
                            }
                        }
                        
                        // Show success message
                        const alertElement = document.createElement('div');
                        alertElement.className = 'alert alert-success alert-dismissible fade show mt-3';
                        alertElement.innerHTML = `
                            ${response.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        `;
                        
                        updateProgressForm.parentNode.insertBefore(alertElement, updateProgressForm.nextSibling);
                    } else {
                        // Show error message
                        const alertElement = document.createElement('div');
                        alertElement.className = 'alert alert-danger alert-dismissible fade show mt-3';
                        alertElement.innerHTML = `
                            ${response.message}
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        `;
                        
                        updateProgressForm.parentNode.insertBefore(alertElement, updateProgressForm.nextSibling);
                    }
                } catch (error) {
                    // Show error message
                    const alertElement = document.createElement('div');
                    alertElement.className = 'alert alert-danger alert-dismissible fade show mt-3';
                    alertElement.innerHTML = `
                        An error occurred. Please try again.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    `;
                    
                    updateProgressForm.parentNode.insertBefore(alertElement, updateProgressForm.nextSibling);
                }
                
                // Remove loading state
                submitBtn.innerHTML = 'Update Progress';
                submitBtn.disabled = false;
                
                // Auto-dismiss alert after 5 seconds
                setTimeout(function() {
                    const alerts = document.querySelectorAll('.alert');
                    alerts.forEach(alert => {
                        const bsAlert = new bootstrap.Alert(alert);
                        bsAlert.close();
                    });
                }, 5000);
            });
            
            // Define what happens in case of error
            xhr.addEventListener('error', function(e) {
                // Show error message
                const alertElement = document.createElement('div');
                alertElement.className = 'alert alert-danger alert-dismissible fade show mt-3';
                alertElement.innerHTML = `
                    An error occurred while updating your progress. Please try again.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                `;
                
                updateProgressForm.parentNode.insertBefore(alertElement, updateProgressForm.nextSibling);
                
                // Remove loading state
                submitBtn.innerHTML = 'Update Progress';
                submitBtn.disabled = false;
            });
            
            // Set up our request
            xhr.open('POST', 'update-progress.php');
            
            // Send the form data
            xhr.send(formData);
        });
    }

    // Range input value display
    const progressRange = document.getElementById('progressRange');
    const progressValue = document.getElementById('progressValue');
    if (progressRange && progressValue) {
        progressRange.addEventListener('input', function() {
            progressValue.textContent = this.value + '%';
        });
    }
});
