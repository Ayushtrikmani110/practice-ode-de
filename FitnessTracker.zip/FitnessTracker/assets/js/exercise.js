/**
 * JavaScript for exercise functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Exercise filter
    const filterButtons = document.querySelectorAll('.exercise-filter-btn');
    if (filterButtons.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const category = this.getAttribute('data-category');
                const exercises = document.querySelectorAll('.exercise-card');
                
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');
                
                // Filter exercises
                exercises.forEach(exercise => {
                    if (category === 'all' || exercise.getAttribute('data-category') === category) {
                        exercise.style.display = 'block';
                    } else {
                        exercise.style.display = 'none';
                    }
                });
            });
        });
    }

    // Exercise difficulty filter
    const difficultyFilter = document.getElementById('difficultyFilter');
    if (difficultyFilter) {
        difficultyFilter.addEventListener('change', function() {
            const difficulty = this.value;
            const exercises = document.querySelectorAll('.exercise-card');
            
            exercises.forEach(exercise => {
                if (difficulty === 'all' || exercise.getAttribute('data-difficulty') === difficulty) {
                    exercise.style.display = 'block';
                } else {
                    exercise.style.display = 'none';
                }
            });
        });
    }

    // Exercise search
    const exerciseSearch = document.getElementById('exerciseSearch');
    if (exerciseSearch) {
        exerciseSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const exercises = document.querySelectorAll('.exercise-card');
            
            exercises.forEach(exercise => {
                const title = exercise.querySelector('.card-title').textContent.toLowerCase();
                const description = exercise.querySelector('.card-text').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || description.includes(searchTerm)) {
                    exercise.style.display = 'block';
                } else {
                    exercise.style.display = 'none';
                }
            });
        });
    }

    // Exercise video player
    const exerciseVideo = document.getElementById('exerciseVideo');
    const playButton = document.getElementById('playExerciseVideo');
    
    if (exerciseVideo && playButton) {
        playButton.addEventListener('click', function() {
            if (exerciseVideo.paused) {
                exerciseVideo.play();
                this.innerHTML = '<i class="fas fa-pause"></i> Pause';
            } else {
                exerciseVideo.pause();
                this.innerHTML = '<i class="fas fa-play"></i> Play';
            }
        });
        
        exerciseVideo.addEventListener('ended', function() {
            playButton.innerHTML = '<i class="fas fa-play"></i> Play';
        });
    }

    // Log exercise form
    const logExerciseForm = document.getElementById('logExerciseForm');
    if (logExerciseForm) {
        logExerciseForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const exerciseId = this.getAttribute('data-exercise-id');
            
            // Add loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
            submitBtn.disabled = true;
            
            // Create an XMLHttpRequest object
            const xhr = new XMLHttpRequest();
            
            // Define what happens on successful data submission
            xhr.addEventListener('load', function(e) {
                const response = JSON.parse(xhr.responseText);
                
                if (response.success) {
                    // Show success message
                    const alertElement = document.createElement('div');
                    alertElement.className = 'alert alert-success alert-dismissible fade show mt-3';
                    alertElement.innerHTML = `
                        ${response.message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    `;
                    
                    logExerciseForm.parentNode.insertBefore(alertElement, logExerciseForm.nextSibling);
                    
                    // Reset form
                    logExerciseForm.reset();
                } else {
                    // Show error message
                    const alertElement = document.createElement('div');
                    alertElement.className = 'alert alert-danger alert-dismissible fade show mt-3';
                    alertElement.innerHTML = `
                        ${response.message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    `;
                    
                    logExerciseForm.parentNode.insertBefore(alertElement, logExerciseForm.nextSibling);
                }
                
                // Remove loading state
                submitBtn.innerHTML = 'Log Exercise';
                submitBtn.disabled = false;
                
                // Auto-dismiss alert after 5 seconds
                setTimeout(function() {
                    const alerts = document.querySelectorAll('.alert');
                    alerts.forEach(alert => {
                        const bsAlert = new bootstrap.Alert(alert);
                        bsAlert.close();
                    });
                }, 5000);
            });
            
            // Define what happens in case of error
            xhr.addEventListener('error', function(e) {
                // Show error message
                const alertElement = document.createElement('div');
                alertElement.className = 'alert alert-danger alert-dismissible fade show mt-3';
                alertElement.innerHTML = `
                    An error occurred while saving your exercise log.
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                `;
                
                logExerciseForm.parentNode.insertBefore(alertElement, logExerciseForm.nextSibling);
                
                // Remove loading state
                submitBtn.innerHTML = 'Log Exercise';
                submitBtn.disabled = false;
            });
            
            // Set up our request
            xhr.open('POST', 'log-exercise.php');
            
            // Send the form data
            xhr.send(formData);
        });
    }
});
