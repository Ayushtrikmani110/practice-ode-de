import axios from 'axios';

// Base URL for API requests
const API_URL = 'http://localhost:5000/api';

// Auth API calls
export const login = async (email, password) => {
  try {
    const response = await axios.post(`${API_URL}/login`, { email, password });
    // Store the token/user data in localStorage
    if (response.data.user) {
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    return response.data;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

export const register = async (userData) => {
  try {
    const response = await axios.post(`${API_URL}/register`, userData);
    if (response.data.user) {
      localStorage.setItem('user', JSON.stringify(response.data.user));
    }
    return response.data;
  } catch (error) {
    console.error('Registration error:', error);
    throw error;
  }
};

export const logout = () => {
  localStorage.removeItem('user');
  return axios.post(`${API_URL}/logout`);
};

// User API calls
export const getUserProfile = async () => {
  try {
    const response = await axios.get(`${API_URL}/profile`);
    return response.data;
  } catch (error) {
    console.error('Get profile error:', error);
    throw error;
  }
};

// Exercises API calls
export const getExercises = async () => {
  try {
    const response = await axios.get(`${API_URL}/exercises`);
    return response.data;
  } catch (error) {
    console.error('Get exercises error:', error);
    throw error;
  }
};

export const getExerciseById = async (id) => {
  try {
    const response = await axios.get(`${API_URL}/exercise/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Get exercise ${id} error:`, error);
    throw error;
  }
};

export const logWorkout = async (exerciseId, workoutData) => {
  try {
    const response = await axios.post(`${API_URL}/exercise/${exerciseId}/log`, workoutData);
    return response.data;
  } catch (error) {
    console.error('Log workout error:', error);
    throw error;
  }
};

// Diet plans API calls
export const getDietPlans = async () => {
  try {
    const response = await axios.get(`${API_URL}/diet-plans`);
    return response.data;
  } catch (error) {
    console.error('Get diet plans error:', error);
    throw error;
  }
};

export const getDietPlanById = async (id) => {
  try {
    const response = await axios.get(`${API_URL}/diet-plan/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Get diet plan ${id} error:`, error);
    throw error;
  }
};

// Challenges API calls
export const getChallenges = async () => {
  try {
    const response = await axios.get(`${API_URL}/challenges`);
    return response.data;
  } catch (error) {
    console.error('Get challenges error:', error);
    throw error;
  }
};

export const getChallengeById = async (id) => {
  try {
    const response = await axios.get(`${API_URL}/challenge/${id}`);
    return response.data;
  } catch (error) {
    console.error(`Get challenge ${id} error:`, error);
    throw error;
  }
};

export const joinChallenge = async (challengeId) => {
  try {
    const response = await axios.post(`${API_URL}/join-challenge/${challengeId}`);
    return response.data;
  } catch (error) {
    console.error('Join challenge error:', error);
    throw error;
  }
};

// Contact form submission
export const submitContactForm = async (formData) => {
  try {
    const response = await axios.post(`${API_URL}/contact`, formData);
    return response.data;
  } catch (error) {
    console.error('Contact form submission error:', error);
    throw error;
  }
};

// Configure axios interceptors for authentication
const setupInterceptors = () => {
  axios.interceptors.request.use(
    (config) => {
      const user = JSON.parse(localStorage.getItem('user'));
      if (user && user.token) {
        config.headers.Authorization = `Bearer ${user.token}`;
      }
      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  axios.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response && error.response.status === 401) {
        // Handle unauthorized access (logout user)
        localStorage.removeItem('user');
        window.location.href = '/login';
      }
      return Promise.reject(error);
    }
  );
};

setupInterceptors();

export default {
  login,
  register,
  logout,
  getUserProfile,
  getExercises,
  getExerciseById,
  logWorkout,
  getDietPlans,
  getDietPlanById,
  getChallenges,
  getChallengeById,
  joinChallenge,
  submitContactForm
};