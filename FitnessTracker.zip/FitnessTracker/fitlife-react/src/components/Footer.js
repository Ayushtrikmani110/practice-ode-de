import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-dark text-white py-5 mt-auto">
      <div className="container">
        <div className="row">
          <div className="col-lg-4 mb-4 mb-lg-0">
            <h4 className="mb-4">FitLife Pro</h4>
            <p>
              Your comprehensive fitness platform providing personalized exercise guides, diet plans, and fitness challenges
              to help you achieve your health and fitness goals.
            </p>
            <div className="social-icons mt-3">
              <a href="#" className="text-white me-3">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-white me-3">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-white me-3">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-white me-3">
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>
          <div className="col-lg-2 col-md-4 mb-4 mb-md-0">
            <h5 className="mb-4">Quick Links</h5>
            <ul className="list-unstyled">
              <li className="mb-2">
                <Link to="/" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Home
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/exercises" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Exercises
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/diet-plans" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Diet Plans
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/challenges" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Challenges
                </Link>
              </li>
              <li className="mb-2">
                <Link to="/contact" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Contact
                </Link>
              </li>
            </ul>
          </div>
          <div className="col-lg-3 col-md-4 mb-4 mb-md-0">
            <h5 className="mb-4">Resources</h5>
            <ul className="list-unstyled">
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Fitness Blog
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Nutrition Guide
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Workout Videos
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>Success Stories
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none">
                  <i className="fas fa-angle-right me-2"></i>FAQ
                </a>
              </li>
            </ul>
          </div>
          <div className="col-lg-3 col-md-4">
            <h5 className="mb-4">Contact Us</h5>
            <ul className="list-unstyled contact-info">
              <li className="mb-3">
                <i className="fas fa-map-marker-alt me-2"></i> 123 Fitness Street, Health District
              </li>
              <li className="mb-3">
                <i className="fas fa-phone me-2"></i> +91 90234 82484
              </li>
              <li className="mb-3">
                <i className="fas fa-envelope me-2"></i> princestudent1310@gmail.com
              </li>
              <li>
                <i className="fas fa-clock me-2"></i> Mon-Fri: 9 AM - 6 PM
              </li>
            </ul>
          </div>
        </div>
        <hr className="my-4" />
        <div className="row">
          <div className="col-md-6 text-center text-md-start">
            <p className="mb-md-0">&copy; {new Date().getFullYear()} FitLife Pro. All rights reserved.</p>
          </div>
          <div className="col-md-6 text-center text-md-end">
            <a href="#" className="text-white text-decoration-none me-3">
              Privacy Policy
            </a>
            <a href="#" className="text-white text-decoration-none me-3">
              Terms of Service
            </a>
            <a href="#" className="text-white text-decoration-none">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;