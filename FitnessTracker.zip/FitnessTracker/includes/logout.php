<?php
require_once 'config.php';
require_once 'auth.php';

// Log the user out
logoutUser();

// Redirect to the home page
$_SESSION['message'] = 'You have been successfully logged out.';
$_SESSION['message_type'] = 'success';

header('Location: ../index.php');
exit;
