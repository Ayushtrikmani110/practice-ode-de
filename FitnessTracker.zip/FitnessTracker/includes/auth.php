<?php
require_once 'config.php';
require_once 'db.php';
require_once 'functions.php';

/**
 * Register a new user
 */
function registerUser($username, $email, $password, $firstName = '', $lastName = '', $age = null, $gender = '') {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Hash the password
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
    // Prepare and execute the SQL statement
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, first_name, last_name, age, gender) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $username, $email, $passwordHash, $firstName, $lastName, $age, $gender);
    
    if ($stmt->execute()) {
        return $conn->insert_id;
    }
    
    return false;
}

/**
 * Login a user
 */
function loginUser($username, $password) {
    $user = getUserByUsername($username);
    
    if ($user && password_verify($password, $user['password'])) {
        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['logged_in'] = true;
        
        return true;
    }
    
    return false;
}

/**
 * Logout a user
 */
function logoutUser() {
    // Unset all session variables
    $_SESSION = [];
    
    // If it's desired to kill the session, also delete the session cookie.
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    
    // Finally, destroy the session.
    session_destroy();
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

/**
 * Check if user is logged in, redirect if not
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Update user profile
 */
function updateUserProfile($userId, $firstName, $lastName, $age, $gender, $height, $weight) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("
        UPDATE users 
        SET first_name = ?, last_name = ?, age = ?, gender = ?, height = ?, weight = ? 
        WHERE id = ?
    ");
    $stmt->bind_param("ssisddi", $firstName, $lastName, $age, $gender, $height, $weight, $userId);
    
    return $stmt->execute();
}

/**
 * Change user password
 */
function changeUserPassword($userId, $currentPassword, $newPassword) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Get current user data
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return false;
    }
    
    $user = $result->fetch_assoc();
    
    // Verify current password
    if (!password_verify($currentPassword, $user['password'])) {
        return false;
    }
    
    // Hash new password
    $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
    
    // Update password
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $newPasswordHash, $userId);
    
    return $stmt->execute();
}
