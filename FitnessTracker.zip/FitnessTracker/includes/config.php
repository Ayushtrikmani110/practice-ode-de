<?php
// Database credentials
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'fitlife_pro');

// Website information
define('SITE_NAME', 'FitLife Pro');
define('SITE_URL', 'http://' . $_SERVER['HTTP_HOST']);

// Session settings
ini_set('session.use_only_cookies', 1);
ini_set('session.use_strict_mode', 1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set default timezone
date_default_timezone_set('UTC');

// Error reporting (turn off in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Define age groups for exercise recommendations
define('AGE_GROUPS', [
    'young' => ['min' => 18, 'max' => 29, 'name' => 'Young Adults (18-29)'],
    'adult' => ['min' => 30, 'max' => 49, 'name' => 'Adults (30-49)'],
    'senior' => ['min' => 50, 'max' => 120, 'name' => 'Seniors (50+)']
]);
