<?php
require_once 'config.php';
require_once 'db.php';

/**
 * Sanitize input data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Validate email format
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Check if username exists
 */
function usernameExists($username) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0;
}

/**
 * Check if email exists
 */
function emailExists($email) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0;
}

/**
 * Get user by ID
 */
function getUserById($userId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Get user by username
 */
function getUserByUsername($username) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Get all exercises
 */
function getAllExercises() {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $result = $conn->query("SELECT * FROM exercises ORDER BY name ASC");
    
    $exercises = [];
    while ($row = $result->fetch_assoc()) {
        $exercises[] = $row;
    }
    
    return $exercises;
}

/**
 * Get exercises by age group
 */
function getExercisesByAgeGroup($age) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM exercises WHERE ? BETWEEN min_age AND max_age ORDER BY name ASC");
    $stmt->bind_param("i", $age);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $exercises = [];
    while ($row = $result->fetch_assoc()) {
        $exercises[] = $row;
    }
    
    return $exercises;
}

/**
 * Get exercise by ID
 */
function getExerciseById($exerciseId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM exercises WHERE id = ?");
    $stmt->bind_param("i", $exerciseId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Get all diet plans
 */
function getAllDietPlans() {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $result = $conn->query("SELECT * FROM diet_plans ORDER BY name ASC");
    
    $dietPlans = [];
    while ($row = $result->fetch_assoc()) {
        $dietPlans[] = $row;
    }
    
    return $dietPlans;
}

/**
 * Get diet plan by ID
 */
function getDietPlanById($dietPlanId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM diet_plans WHERE id = ?");
    $stmt->bind_param("i", $dietPlanId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Get all challenges
 */
function getAllChallenges() {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $result = $conn->query("SELECT * FROM challenges ORDER BY name ASC");
    
    $challenges = [];
    while ($row = $result->fetch_assoc()) {
        $challenges[] = $row;
    }
    
    return $challenges;
}

/**
 * Get challenge by ID
 */
function getChallengeById($challengeId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("SELECT * FROM challenges WHERE id = ?");
    $stmt->bind_param("i", $challengeId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Get user challenges
 */
function getUserChallenges($userId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    $stmt = $conn->prepare("
        SELECT uc.*, c.name, c.description, c.image_url, c.difficulty, c.duration, c.points
        FROM user_challenges uc
        JOIN challenges c ON uc.challenge_id = c.id
        WHERE uc.user_id = ?
        ORDER BY uc.start_date DESC
    ");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $challenges = [];
    while ($row = $result->fetch_assoc()) {
        $challenges[] = $row;
    }
    
    return $challenges;
}

/**
 * Join a challenge
 */
function joinChallenge($userId, $challengeId) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Check if user is already enrolled in this challenge
    $stmt = $conn->prepare("SELECT id FROM user_challenges WHERE user_id = ? AND challenge_id = ? AND (status = 'started' OR status = 'in_progress')");
    $stmt->bind_param("ii", $userId, $challengeId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return false; // Already enrolled
    }
    
    // Enroll user in challenge
    $stmt = $conn->prepare("INSERT INTO user_challenges (user_id, challenge_id, status, progress) VALUES (?, ?, 'started', 0)");
    $stmt->bind_param("ii", $userId, $challengeId);
    
    return $stmt->execute();
}

/**
 * Update challenge progress
 */
function updateChallengeProgress($userChallengeId, $progress) {
    $db = Database::getInstance();
    $conn = $db->getConnection();
    
    // Get the challenge details
    $stmt = $conn->prepare("
        SELECT uc.*, c.duration
        FROM user_challenges uc
        JOIN challenges c ON uc.challenge_id = c.id
        WHERE uc.id = ?
    ");
    $stmt->bind_param("i", $userChallengeId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return false;
    }
    
    $challenge = $result->fetch_assoc();
    
    // Update progress
    $status = $progress >= 100 ? 'completed' : ($progress > 0 ? 'in_progress' : 'started');
    $completionDate = $progress >= 100 ? date('Y-m-d H:i:s') : null;
    
    $stmt = $conn->prepare("
        UPDATE user_challenges
        SET progress = ?, status = ?, completion_date = ?
        WHERE id = ?
    ");
    $stmt->bind_param("issi", $progress, $status, $completionDate, $userChallengeId);
    
    return $stmt->execute();
}

/**
 * Get appropriate age group for user
 */
function getUserAgeGroup($age) {
    foreach (AGE_GROUPS as $key => $group) {
        if ($age >= $group['min'] && $age <= $group['max']) {
            return $key;
        }
    }
    
    return 'adult'; // Default to adult if not found
}

/**
 * Format date for display
 */
function formatDate($date) {
    return date('F j, Y', strtotime($date));
}

/**
 * Calculate BMI
 */
function calculateBMI($weight, $height) {
    // Weight in kg, height in meters
    if ($height <= 0) return 0;
    
    return round($weight / ($height * $height), 1);
}

/**
 * Get BMI category
 */
function getBMICategory($bmi) {
    if ($bmi < 18.5) {
        return 'Underweight';
    } elseif ($bmi >= 18.5 && $bmi < 25) {
        return 'Normal weight';
    } elseif ($bmi >= 25 && $bmi < 30) {
        return 'Overweight';
    } else {
        return 'Obesity';
    }
}
