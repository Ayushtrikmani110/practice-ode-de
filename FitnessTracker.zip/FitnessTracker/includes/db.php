<?php
require_once 'config.php';

/**
 * Database connection class
 */
class Database {
    private $connection;
    private static $instance = null;
    
    /**
     * Private constructor to prevent direct creation
     */
    private function __construct() {
        $this->connection = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
        
        if ($this->connection->connect_error) {
            die("Connection failed: " . $this->connection->connect_error);
        }
        
        $this->connection->set_charset("utf8mb4");
    }
    
    /**
     * Get database instance (singleton pattern)
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        
        return self::$instance;
    }
    
    /**
     * Get database connection
     */
    public function getConnection() {
        return $this->connection;
    }
    
    /**
     * Execute a query
     */
    public function query($sql) {
        return $this->connection->query($sql);
    }
    
    /**
     * Prepare a statement
     */
    public function prepare($sql) {
        return $this->connection->prepare($sql);
    }
    
    /**
     * Get the ID of the last inserted row
     */
    public function getLastId() {
        return $this->connection->insert_id;
    }
    
    /**
     * Escape a string for SQL
     */
    public function escapeString($string) {
        return $this->connection->real_escape_string($string);
    }
    
    /**
     * Close the connection
     */
    public function close() {
        $this->connection->close();
    }
    
    /**
     * Create necessary tables if they don't exist
     */
    public function createTables() {
        // Users table
        $this->query("CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            first_name VARCHAR(50),
            last_name VARCHAR(50),
            age INT,
            gender VARCHAR(10),
            height FLOAT,
            weight FLOAT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )");
        
        // Exercises table
        $this->query("CREATE TABLE IF NOT EXISTS exercises (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT NOT NULL,
            image_url VARCHAR(255),
            gif_url VARCHAR(255),
            category VARCHAR(50) NOT NULL,
            difficulty VARCHAR(20) NOT NULL,
            target_muscle VARCHAR(50) NOT NULL,
            min_age INT DEFAULT 0,
            max_age INT DEFAULT 120,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Diet plans table
        $this->query("CREATE TABLE IF NOT EXISTS diet_plans (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT NOT NULL,
            image_url VARCHAR(255),
            category VARCHAR(50) NOT NULL,
            calories INT,
            protein FLOAT,
            carbs FLOAT,
            fat FLOAT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // Challenges table
        $this->query("CREATE TABLE IF NOT EXISTS challenges (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT NOT NULL,
            image_url VARCHAR(255),
            difficulty VARCHAR(20) NOT NULL,
            duration INT NOT NULL,
            points INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        
        // User challenges table
        $this->query("CREATE TABLE IF NOT EXISTS user_challenges (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            challenge_id INT NOT NULL,
            status VARCHAR(20) DEFAULT 'started',
            progress INT DEFAULT 0,
            start_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completion_date TIMESTAMP NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (challenge_id) REFERENCES challenges(id) ON DELETE CASCADE
        )");
        
        // User workouts table
        $this->query("CREATE TABLE IF NOT EXISTS user_workouts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            exercise_id INT NOT NULL,
            date DATE NOT NULL,
            sets INT DEFAULT 0,
            reps INT DEFAULT 0,
            weight FLOAT DEFAULT 0,
            duration INT DEFAULT 0,
            notes TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (exercise_id) REFERENCES exercises(id) ON DELETE CASCADE
        )");
        
        // Insert some sample data for exercises
        $this->insertSampleExercises();
        
        // Insert some sample data for diet plans
        $this->insertSampleDietPlans();
        
        // Insert some sample data for challenges
        $this->insertSampleChallenges();
    }
    
    /**
     * Insert sample exercises
     */
    private function insertSampleExercises() {
        $count = $this->query("SELECT COUNT(*) as count FROM exercises")->fetch_assoc()['count'];
        
        if ($count == 0) {
            // Young adults exercises (18-29)
            $this->query("INSERT INTO exercises (name, description, image_url, gif_url, category, difficulty, target_muscle, min_age, max_age) VALUES 
            ('Push-ups', 'A classic bodyweight exercise targeting the chest, shoulders, and triceps. Start in a plank position with hands slightly wider than shoulder-width apart. Lower your body until your chest nearly touches the floor, then push back up.', 'https://images.unsplash.com/photo-1518611012118-696072aa579a', '', 'Strength', 'Beginner', 'Chest', 18, 29),
            ('Pull-ups', 'An upper body exercise that primarily targets the back and biceps. Hang from a bar with palms facing away from you, then pull yourself up until your chin is over the bar.', 'https://images.unsplash.com/photo-1518310383802-640c2de311b2', '', 'Strength', 'Intermediate', 'Back', 18, 29),
            ('Burpees', 'A full-body exercise that combines a squat, push-up, and jump. Start standing, drop into a squat position, kick feet back into a plank, perform a push-up, return to squat, and jump up.', 'https://images.unsplash.com/photo-1518644961665-ed172691aaa1', '', 'Cardio', 'Advanced', 'Full Body', 18, 29),
            ('Bench Press', 'A compound exercise that targets the chest, shoulders, and triceps. Lie on a bench, grip the barbell with hands wider than shoulder-width, lower the bar to chest level, then press back up.', 'https://images.unsplash.com/photo-1518310952931-b1de897abd40', '', 'Strength', 'Intermediate', 'Chest', 18, 29),
            ('Deadlift', 'A compound exercise that works the entire posterior chain. With feet hip-width apart, bend at the hips and knees to grip the barbell, then stand up straight while keeping the bar close to the body.', 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd', '', 'Strength', 'Advanced', 'Back', 18, 29),
            ('Squats', 'A lower body exercise targeting the quads, hamstrings, and glutes. Stand with feet shoulder-width apart, lower your body by bending your knees and hips as if sitting in a chair, then return to standing.', 'https://images.unsplash.com/photo-1434754205268-ad3b5f549b11', '', 'Strength', 'Beginner', 'Legs', 18, 29),
            ('Plank', 'A core strengthening exercise. Start in a push-up position but with forearms on the ground. Keep your body in a straight line from head to heels, engaging your core.', 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8', '', 'Core', 'Beginner', 'Abs', 18, 29),
            ('Jumping Jacks', 'A classic cardio exercise. Stand with feet together and arms at sides, then jump while spreading legs and raising arms overhead, then return to starting position.', 'https://images.unsplash.com/photo-1518459031867-a89b944bffe4', '', 'Cardio', 'Beginner', 'Full Body', 18, 29),
            ('Mountain Climbers', 'A dynamic exercise that works multiple muscle groups. Start in a plank position, then alternately drive each knee toward your chest in a running motion.', 'https://images.unsplash.com/photo-1483721310020-03333e577078', '', 'Cardio', 'Intermediate', 'Full Body', 18, 29),
            ('Box Jumps', 'A plyometric exercise that builds explosive power. Stand in front of a sturdy box, lower into a quarter squat, then explosively jump onto the box, landing softly.', 'https://images.unsplash.com/photo-1445384763658-0400939829cd', '', 'Plyometric', 'Intermediate', 'Legs', 18, 29),
            
            ('Modified Push-ups', 'A beginner-friendly version of push-ups that targets the chest, shoulders, and triceps. Perform push-ups with knees on the ground to reduce resistance.', 'https://images.unsplash.com/photo-1518611012118-696072aa579a', '', 'Strength', 'Beginner', 'Chest', 30, 49),
            ('Assisted Pull-ups', 'An upper body exercise using a resistance band for assistance. Loop a band around the pull-up bar, place one foot or knee in the band, and perform pull-ups with reduced body weight.', 'https://images.unsplash.com/photo-1518310383802-640c2de311b2', '', 'Strength', 'Intermediate', 'Back', 30, 49),
            ('Modified Burpees', 'A lower-impact version of burpees without the jump. Perform the movement more slowly and step back to plank position instead of jumping.', 'https://images.unsplash.com/photo-1518644961665-ed172691aaa1', '', 'Cardio', 'Intermediate', 'Full Body', 30, 49),
            ('Dumbbell Press', 'A chest exercise using dumbbells instead of a barbell for greater range of motion. Lie on a bench, hold dumbbells at chest level, then press upward.', 'https://images.unsplash.com/photo-1518310952931-b1de897abd40', '', 'Strength', 'Intermediate', 'Chest', 30, 49),
            ('Romanian Deadlift', 'A variation of the deadlift that focuses on the hamstrings and lower back. Start standing, hinge at the hips while keeping legs mostly straight, lower the weight, then return to standing.', 'https://images.unsplash.com/photo-1597075958252-60fc09ec20c2', '', 'Strength', 'Intermediate', 'Back', 30, 49),
            ('Goblet Squats', 'A squat variation holding a dumbbell or kettlebell at chest level. This helps maintain proper form while building lower body strength.', 'https://images.unsplash.com/photo-1434754205268-ad3b5f549b11', '', 'Strength', 'Beginner', 'Legs', 30, 49),
            ('Side Plank', 'A core exercise targeting the obliques. Lie on your side, prop yourself up on one forearm, and raise your hips to create a straight line from head to feet.', 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8', '', 'Core', 'Intermediate', 'Abs', 30, 49),
            ('Low-Impact Jumping Jacks', 'A modified version of jumping jacks that reduces impact. Step side to side instead of jumping, while raising arms overhead.', 'https://images.unsplash.com/photo-1518459031867-a89b944bffe4', '', 'Cardio', 'Beginner', 'Full Body', 30, 49),
            ('Standing Bicycle Crunches', 'A standing version of the bicycle crunch. Stand with feet shoulder-width apart, bring one knee up while twisting to touch it with the opposite elbow.', 'https://images.unsplash.com/photo-1483721310020-03333e577078', '', 'Core', 'Beginner', 'Abs', 30, 49),
            ('Step-ups', 'A lower body exercise using a step or bench. Step onto the platform with one foot, then the other, then step back down in the same order.', 'https://images.unsplash.com/photo-1445384763658-0400939829cd', '', 'Strength', 'Beginner', 'Legs', 30, 49),
            
            ('Wall Push-ups', 'A very beginner-friendly push-up variation. Stand facing a wall at arm\'s length, place hands on the wall, then bend elbows to bring chest toward the wall before pushing back.', 'https://images.unsplash.com/photo-1518611012118-696072aa579a', '', 'Strength', 'Beginner', 'Chest', 50, 120),
            ('Chair Assisted Pull-ups', 'A modified pull-up using a chair for support. Place a chair beneath a pull-up bar, use legs for assistance while still engaging upper body muscles.', 'https://images.unsplash.com/photo-1518310383802-640c2de311b2', '', 'Strength', 'Beginner', 'Back', 50, 120),
            ('Chair Squats', 'A squat variation using a chair for safety and form. Stand in front of a chair, lower yourself until just touching the seat, then stand back up.', 'https://images.unsplash.com/photo-1434754205268-ad3b5f549b11', '', 'Strength', 'Beginner', 'Legs', 50, 120),
            ('Seated Shoulder Press', 'An upper body exercise performed while seated for stability. Hold light dumbbells at shoulder height, then press upward.', 'https://images.unsplash.com/photo-1518310952931-b1de897abd40', '', 'Strength', 'Beginner', 'Shoulders', 50, 120),
            ('Seated Row with Resistance Band', 'A back-strengthening exercise using a resistance band. Sit with legs extended, loop band around feet, pull band toward waist while maintaining good posture.', 'https://images.unsplash.com/photo-1518310383802-640c2de311b2', '', 'Strength', 'Beginner', 'Back', 50, 120),
            ('Wall Planks', 'A modified plank for beginners. Stand facing a wall, place forearms on the wall, and lean forward while maintaining a straight body line.', 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8', '', 'Core', 'Beginner', 'Abs', 50, 120),
            ('Seated Marching', 'A low-impact cardio exercise. Sit on the edge of a chair and alternately lift knees toward chest in a marching motion.', 'https://images.unsplash.com/photo-1518459031867-a89b944bffe4', '', 'Cardio', 'Beginner', 'Legs', 50, 120),
            ('Wall Angels', 'A posture-improving exercise. Stand with back against a wall, arms at 90 degrees, then slide arms up and down while maintaining contact with the wall.', 'https://images.unsplash.com/photo-1483721310020-03333e577078', '', 'Mobility', 'Beginner', 'Shoulders', 50, 120),
            ('Seated Leg Extensions', 'A quadriceps strengthening exercise. Sit on a chair, extend one leg until straight, hold briefly, then lower.', 'https://images.unsplash.com/photo-1434754205268-ad3b5f549b11', '', 'Strength', 'Beginner', 'Legs', 50, 120),
            ('Ankle Rotations', 'A mobility exercise for the ankles. Sit on a chair, lift one foot off the ground, and rotate the ankle in circles in both directions.', 'https://images.unsplash.com/photo-1445384763658-0400939829cd', '', 'Mobility', 'Beginner', 'Ankles', 50, 120)");
        }
    }
    
    /**
     * Insert sample diet plans
     */
    private function insertSampleDietPlans() {
        $count = $this->query("SELECT COUNT(*) as count FROM diet_plans")->fetch_assoc()['count'];
        
        if ($count == 0) {
            $this->query("INSERT INTO diet_plans (name, description, image_url, category, calories, protein, carbs, fat) VALUES 
            ('High Protein Muscle Building', 'A diet plan focused on building muscle mass with high protein intake and adequate carbohydrates for energy.', 'https://images.unsplash.com/photo-1625229466790-62bae5ab4ff4', 'Muscle Gain', 2800, 200, 250, 80),
            ('Fat Loss & Lean Muscle', 'A balanced diet plan that promotes fat loss while preserving lean muscle mass.', 'https://images.unsplash.com/photo-1540289917366-db90f08d2397', 'Weight Loss', 1800, 150, 150, 60),
            ('Vegan Fitness Plan', 'A plant-based diet plan providing all essential nutrients for active individuals without animal products.', 'https://images.unsplash.com/photo-1625574199327-6c8a521117d5', 'Vegan', 2200, 120, 280, 70),
            ('Keto Performance', 'A low-carb, high-fat diet plan designed to achieve ketosis while maintaining athletic performance.', 'https://images.unsplash.com/photo-1470549813517-2fa741d25c92', 'Keto', 2000, 150, 50, 150),
            ('Mediterranean Fitness', 'A heart-healthy diet based on Mediterranean cuisine, rich in olive oil, whole grains, and lean proteins.', 'https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea', 'Mediterranean', 2400, 130, 220, 90),
            ('Paleo Athlete', 'A diet plan based on foods presumed to have been available to paleolithic humans, focusing on meats, fish, fruits, and vegetables.', 'https://images.unsplash.com/photo-1477506350614-fcdc29a3b157', 'Paleo', 2300, 170, 120, 110),
            ('Intermittent Fasting Plan', 'A meal timing approach that cycles between periods of eating and fasting, with nutritionally complete meals during eating windows.', 'https://images.unsplash.com/photo-1464454709131-ffd692591ee5', 'Intermittent Fasting', 2000, 140, 180, 70),
            ('Senior Nutrition Plan', 'A balanced diet plan designed for older adults, with adequate protein to prevent muscle loss and nutrients for bone health.', 'https://images.unsplash.com/photo-1437750769465-301382cdf094', 'Senior Fitness', 1900, 120, 200, 65),
            ('Vegetarian Strength Builder', 'A vegetarian diet plan with ample plant-based proteins and nutrients to support strength training.', 'https://images.unsplash.com/photo-1457347876270-97799484c564', 'Vegetarian', 2400, 140, 270, 75),
            ('Clean Eating Plan', 'A diet plan focusing on whole, unprocessed foods while eliminating refined sugars, trans fats, and artificial ingredients.', 'https://images.unsplash.com/photo-1466065478348-0b967011f8e0', 'Clean Eating', 2100, 130, 210, 70)");
        }
    }
    
    /**
     * Insert sample challenges
     */
    private function insertSampleChallenges() {
        $count = $this->query("SELECT COUNT(*) as count FROM challenges")->fetch_assoc()['count'];
        
        if ($count == 0) {
            $this->query("INSERT INTO challenges (name, description, image_url, difficulty, duration, points) VALUES 
            ('30-Day Push-up Challenge', 'Gradually increase your push-up count over 30 days, starting with as few as 5 per day and building up to 50 or more by the end.', 'https://images.unsplash.com/photo-1518644961665-ed172691aaa1', 'Intermediate', 30, 300),
            ('21-Day Plank Master', 'Build core strength by holding planks for longer durations each day, starting with 30 seconds and working up to 5 minutes.', 'https://images.unsplash.com/photo-1518310383802-640c2de311b2', 'Beginner', 21, 210),
            ('14-Day Water Challenge', 'Drink at least 3 liters of water daily for 14 days to improve hydration, skin health, and overall well-being.', 'https://images.unsplash.com/photo-1518644961665-ed172691aaa1', 'Beginner', 14, 140),
            ('60-Day Transformation Challenge', 'Complete a comprehensive 60-day program including strength training, cardio, and nutrition guidelines for a total body transformation.', 'https://images.unsplash.com/photo-1483721310020-03333e577078', 'Advanced', 60, 600),
            ('10,000 Steps Challenge', 'Walk at least 10,000 steps every day for 30 days to improve cardiovascular health and burn extra calories.', 'https://images.unsplash.com/photo-1518611012118-696072aa579a', 'Beginner', 30, 300),
            ('7-Day Sugar Detox', 'Eliminate all added sugars from your diet for 7 days to reset your taste buds and reduce sugar cravings.', 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5', 'Intermediate', 7, 150),
            ('28-Day Squat Challenge', 'Build lower body strength by performing an increasing number of squats each day for 28 days.', 'https://images.unsplash.com/photo-1518459031867-a89b944bffe4', 'Intermediate', 28, 280),
            ('3-Week Flexibility Journey', 'Improve your flexibility through daily stretching routines, gradually increasing duration and intensity.', 'https://images.unsplash.com/photo-1518644961665-ed172691aaa1', 'Beginner', 21, 210),
            ('100 Pull-ups Challenge', 'Complete 100 pull-ups within a single workout by the end of this 45-day progressive training program.', 'https://images.unsplash.com/photo-1518310383802-640c2de311b2', 'Advanced', 45, 450),
            ('30-Day Morning Workout', 'Commit to exercising for at least 15 minutes every morning for 30 days to establish a consistent fitness habit.', 'https://images.unsplash.com/photo-1518459031867-a89b944bffe4', 'Beginner', 30, 300)");
        }
    }
}

// Create an instance and initialize tables
$database = Database::getInstance();
$database->createTables();
